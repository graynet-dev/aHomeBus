#ifndef AHB_NODE_H
#define AHB_NODE_H
    #include "ahb.h"
    #include "ahb_proto.h"
    
class AHB_NODE { 
public:            
            
            AHB_NODE(uint8_t id); 
  
};
    
#endif /* AHB_NODE_H */