#ifndef AHB_NODE_C
#define AHB_NODE_C
    #include "ahb_node.h"

AHB_NODE::AHB_NODE(uint8_t id){

} 
  
    
#endif /* AHB_NODE_C */