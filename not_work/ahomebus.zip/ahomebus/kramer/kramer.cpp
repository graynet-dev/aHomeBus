# pAVGrid 
#
# Python Audio/Video grid controller
#
# (c) 2003 Jerome Alet - <alet@unice.fr>
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
#

# 
# WARNING : NOT ALL CALLBACKS ARE IMPLEMENTED YET !
#           SO BE CAREFUL WITH WHAT YOU DO !
#

import sys
import time

try :
    import serial
    from serial.serialutil import SerialException
except ImportError :    
    sys.stderr.write("I'm sorry to tell you that you need the PySerial python module, please find it on SourceForge.\n")
    sys.exit(-1)

class Protocol2000Error(Exception):
    """An exception for Protocol 2000."""
    def __init__(self, message = ""):
        self.message = message
        Exception.__init__(self, message)
    def __repr__(self):
        return self.message
    __str__ = __repr__
    
DEFAULT_TIMEOUT = 1     # one second

ACTION_HASFUNCTION = 0x7F    
    
DEFAULT_MACHINE = 1    
DEFAULT_OUTPUT = 1    

SETUP_REGISTER_0 = 0    
SETUP_REGISTER_1 = 1
SETUP_REGISTER_2 = 2    
SETUP_REGISTER_3 = 3    
SETUP_REGISTER_4 = 4    
SETUP_REGISTER_5 = 5    
SETUP_REGISTER_6 = 6    
SETUP_REGISTER_7 = 7    
SETUP_REGISTER_8 = 8    
SETUP_REGISTER_9 = 9    
SETUP_REGISTER_10 = 10   
SETUP_REGISTER_11 = 11   
SETUP_REGISTER_12 = 12   
SETUP_REGISTER_13 = 13   
SETUP_REGISTER_14 = 14   
SETUP_REGISTER_15 = 15   
SETUP_REGISTER_CURRENT = SETUP_REGISTER_0

ACTION_RECALL_STATUS = 0
ACTION_STORE_STATUS = 0    
ACTION_DELETE_STATUS = 1

ACTION_DISCONNECT = 0
ALL_OUTPUTS = 0

ACTION_AUDIO_FOLLOW_VIDEO = 0
ACTION_AUDIO_BREAKAWAY = 1

ACTION_VIDEO = 0
ACTION_AUDIO = 1

ACTION_NO_AUTOSAVE = 0
ACTION_AUTOSAVE = 1

ACTION_VIDEO_MACHINE_NAME = 1
ACTION_AUDIO_MACHINE_NAME = 2
ACTION_VIDEO_SOFTWARE_VERSION = 3
ACTION_AUDIO_SOFTWARE_VERSION = 4
ACTION_REMOTE_CONTROL_NAME = 7
ACTION_REMOTE_SOFTWARE_VERSION = 8

DEFINE_VIDEO = 1
DEFINE_AUDIO = 2
DEFINE_SDI = 3
DEFINE_REMOTE = 4

ACTION_DEFINE_INPUTS = 1
ACTION_DEFINE_OUTPUTS = 2
ACTION_DEFINE_SETUPS = 3

ERROR_ERROR = 0
ERROR_INVALID_INSTRUCTION = 1
ERROR_OUT_OF_RANGE = 2
ERROR_MACHINE_BUSY = 3

STATUS_OFF = 0
STATUS_ON = 1

MAX_SDI = 0x1F          # TODO : check
MAX_REMOTE = 0x1F       # TODO : check

Protocol2000_Instructions = {    
                                "Reset Video" : 0,
                                "Switch Video" : 1,
                                "Switch Audio" : 2,
                                "Store Video Status" : 3,
                                "Recall Video Status" : 4,
                                "Request Video Output Status" : 5,
                                "Request Audio Output Status" : 6,
                                "VIS Source" : 7,
                                "Breakaway Setting" : 8,
                                "Video Audio Type Setting" : 9,
                                "Request VIS Setting" : 10,
                                "Request Breakaway Setting" : 11,
                                "Request Video Audio Type Setting" : 12,
                                "Set Highest Machine Number" : 13,
                                "Request Highest Machine Number" : 14,
                                "Request Whether Setup Is Defined" : 15,
                                "Error Busy" : 16,
                                "Reserved 17" : 17,
                                "Reset Audio" : 18,
                                "Store Audio Status" : 19,
                                "Recall Audio Status" : 20,
                                "Set Video Gain" : 21,
                                "Set Audio Gain" : 22,
                                "Increase Decrease Video Gain" : 23,
                                "Increase Decrease Audio Gain" : 24,
                                "Request Gain" : 25,
                                # what is missing here ?
                                "Set Auto Save" : 57,
                                "Reserved 58" : 58,
                                "Reserved 59" : 59,
                                "Reserved 60" : 60,
                                "Identify Machine" : 61,
                                "Define Machine" : 62
                            }
                            
class Protocol2000 :
    """Implements the Kramer Electronics Protocol 2000."""
    SerialLink = None
    
    def __init__(self, device="/dev/tts/0", timeout=DEFAULT_TIMEOUT, debug=0) :
        """Initializes the serial link with the Audio/Video grid."""
        self.debug = debug
        self.SerialLink = serial.Serial(device, baudrate=9600, 
                                          bytesize=serial.EIGHTBITS, 
                                          parity=serial.PARITY_NONE, 
                                          stopbits=serial.STOPBITS_ONE,
                                          xonxoff=0,
                                          rtscts=0,
                                          timeout=timeout)
        self.Machines = {}
        self.toMachine("Request Highest Machine Number", ACTION_VIDEO, 0, DEFAULT_MACHINE)
        data = self.receiveData()
        try :
            number = ord(data[2]) & 0x7F
            if not number :
                number = 1
        except IndexError :    
            # No answer (timeout), assume only one.
            number = 1
        for i in range(1, number + 1) :
            Protocol2000_Machine(self, i)
                
    def __del__(self) :    
        """Ensures the serial link is closed on deletion."""
        self.close()
            
    def close(self) :        
        """Closes the serial link if it is open."""
        if self.SerialLink is not None :
            self.SerialLink.close()
            
    def registerMachine(self, machine) :        
        """Registers a machine."""
        self.Machines[machine.id] = machine 
        
    def unregisterMachine(self, machine) :        
        """Unregisters a machine."""
        try :
            del self.Machines[machine.id]
        except KeyError :    
            pass
        
    def debugInfo(self, msg) :        
        """Outputs debug information."""
        if self.debug :
            sys.stdout.write(msg)
            sys.stdout.flush()
            
    def normalizeInstruction(self, instruction) :
        """Ensures that an instruction is correct."""
        if instruction & 0xC0 :
            raise Protocol2000Error, "Invalid instruction %i" % instruction
        return instruction & 0x3F
            
    def normalizeInput(self, input) :
        """Ensures that an input channel is between protocol limits."""
        if input & 0x80 :
            raise Protocol2000Error, "Invalid input channel %i" % input
        return 0x80 | (input & 0x7F)
            
    def normalizeOutput(self, output) :
        """Ensures that an output channel is between protocol limits."""
        if output & 0x80 :
            raise Protocol2000Error, "Invalid output channel %i" % output
        return 0x80 | (output & 0x7F)
            
    def normalizeMachine(self, machinenumber) :
        """Ensures that a machine number is between protocol limits."""
        if machinenumber & 0xE0 :
            raise Protocol2000Error, "Invalid machine number %i" % machinenumber
        return 0x80 | (machinenumber & 0x1F)
            
    def receiveData(self) :        
        """Reads a data chunk from the grid."""
        self.lastanswer = self.SerialLink.read(4)
        self.debugInfo("read [%s]\n" % ", ".join(["0x%02x" % ord(d) for d in self.lastanswer]))
        return self.lastanswer
        
    def sendData(self, data) :        
        """Sends data to the grid."""
        if len(data) != 4 :
            raise Protocol2000Error, "Can't send invalid data [%s]" % ", ".join(["0x%02x" % d for d in data])
        self.debugInfo("write [%s]\n" % ", ".join(["0x%02x" % d for d in data]))
        self.SerialLink.write("".join([chr(d) for d in data]))
            
    def toMachine(self, instruction, input, output=DEFAULT_OUTPUT, machine=DEFAULT_MACHINE) :
        """Sends an instruction to the specified machine."""
        # Protocol 2000 sucks ! Function 62 (define machine) doesn't 
        # answer the (video, audio, SDI, remote) type we asked for,
        # so we have to keep the last transmitted values somewhere.
        # other functions behave the same.
        self.lastinstruction = instruction
        try :
            instruction = Protocol2000_Instructions[instruction]
        except KeyError :    
            raise Protocol2000Error, "Invalid instruction [%s]" % instruction
        self.lastinput = input
        self.lastoutput = output
        self.lastmachine = machine
        self.sendData((self.normalizeInstruction(instruction), \
                       self.normalizeInput(input), \
                       self.normalizeOutput(output), \
                       self.normalizeMachine(machine)))
        
###############################################################################""    

class Protocol2000_Machine :        
    """Class for Protocol2000 Machines."""
    
    def __init__(self, parent = None, machineid = DEFAULT_MACHINE, debug=0) :
        """Initializes an audio or video machine."""
        self.debug = debug
        self.parent = parent
        if parent is None :
            self.parent = Protocol2000(debug=debug)
        else :    
            self.parent = parent
        self.id = machineid
        
        self.hasBreakawaySetting = False
        self.currentBreakawaySetting = ACTION_AUDIO_FOLLOW_VIDEO
        
        self.parent.registerMachine(self)
        
        self.callbacks = {}                                  
        for (k, v) in Protocol2000_Instructions.items() :
            name = k.lower().replace(" ", "_")
            self.callbacks[0x40 | v] = "event_" + name
        
    def __del__(self) :
        """Unregisters a machine."""
        self.parent.unregisterMachine(self)
        
    def dialog(self, instruction, input, output) :    
        """Sends an instruction to the machine and handles the answer."""
        self.parent.toMachine(instruction, input, output, self.id)
        self.lastanswer = self.parent.receiveData()
        try :
            (ansinput, ansoutput, ansmachine) = [ord(d) & 0x7F for d in self.lastanswer[1:]]
            ansmachine &= 0x1F
        except ValueError :
            pass
        else :    
            # extract the event name
            try :
                event = self.callbacks[ord(self.lastanswer[0])]
            except AttributeError :    
                raise Protocol2000Error, "Unknown answer (%s)" % ", ".join(["0x%02x" % b for b in self.lastanswer])
            except KeyError :    
                return # TODO : ne plus ignorer !
                
            try :
                # NOTE : we use self, instead of calling the machine which number 
                # is present in the answer, because they don't match sometimes.
                method = getattr(self, event)
            except AttributeError :    
                raise Protocol2000Error, "Method %s not yet implemented" % event
            self.parent.debugInfo("%s(%i, %i, %i)\n" % (event, ansinput, ansoutput, ansmachine))
            
            # call the actual event handler
            try :
                apply(method, (ansinput, ansoutput))
            except Protocol2000Error, msg :     
                raise Protocol2000Error, "Invalid event %s(%i, %i, %i) %s" % (event, ansinput, ansoutput, ansmachine, msg or "")
        return self.lastanswer            
        
    #
    # Events callbacks    
    
    def event_breakaway_setting(self, input, output) :
        """Receive a breakaway setting event."""
        self.currentBreakawaySetting = output
        
    def event_request_breakaway_setting(self, input, output) :
        """Receive the breakaway setting."""
        if input == ACTION_HASFUNCTION :
            self.hasBreakawaySetting = output
            if not output :
                self.currentBreakawaySetting = ACTION_AUDIO_FOLLOW_VIDEO
        else :    
            self.currentBreakawaySetting = output
        
    def event_request_video_output_status(self, input, output) :
        """Receive a video output status."""
        if not hasattr(self, "VideoOutputs") :
            self.VideoOutputs = {}
        self.VideoOutputs[self.parent.lastoutput] = output
        
    def event_request_audio_output_status(self, input, output) :
        """Receive a audio output status."""
        if not hasattr(self, "AudioOutputs") :
            self.AudioOutputs = {}
        self.AudioOutputs[self.parent.lastoutput] = output
        
    def event_error_busy(self, input, output) :
        """Receive an Error/Busy message."""
        self.errorcode = output
        if self.errorcode == ERROR_ERROR :
            msg = "Error"
        elif self.errorcode == ERROR_INVALID_INSTRUCTION :
            msg = "Invalid instruction"
        elif self.errorcode == ERROR_OUT_OF_RANGE :
            msg = "Out of range"
        elif self.errorcode == ERROR_MACHINE_BUSY :
            msg = "Machine busy"
        else :    
            msg = "Unknown error"
        self.errormessage = "%s : %s (0x%02x, 0x%02x, 0x%02x)" % \
            (msg, self.parent.lastinstruction, self.parent.lastinput, self.parent.lastoutput, 
                  self.parent.lastmachine)
        sys.stderr.write("%s\n" % self.errormessage)          
        sys.stderr.flush()
            
    def event_reset_video(self, input, output) :
        """Receive a reset video event."""
        pass
        
    def event_reset_audio(self, input, output) :
        """Receive a reset audio event."""
        pass
        
    def event_switch_video(self, input, output) :
        """Gets current video input and output for a machine."""
        if not hasattr(self, "VideoInputs") :
            self.VideoInputs = {}
        self.VideoInputs[input] = output
    
    def event_switch_audio(self, input, output) :
        """Gets current audio input and output for a machine."""
        if not hasattr(self, "AudioInputs") :
            self.AudioInputs = {}
        self.AudioInputs[input] = output
    
    def event_request_highest_machine_number(self, input, output) :
        """Gets the highest audio or video machine number."""
        if input == ACTION_AUDIO :
            self.numberOfAudioMachines = output
        elif input == ACTION_VIDEO :
            self.numberOfVideoMachines = output
        else :
            raise Protocol2000Error
            
    def event_identify_machine(self, input, output) :        
        """Identifies a machine components."""
        if self.parent.lastinput in (ACTION_VIDEO_MACHINE_NAME, ACTION_AUDIO_MACHINE_NAME) :
            self.MachineName = "%i%02i" % (input, output)
        elif self.parent.lastinput in (ACTION_VIDEO_SOFTWARE_VERSION, ACTION_AUDIO_SOFTWARE_VERSION) :
            self.SoftwareVersion = "%i.%02i" % (input, output)
        else :    
            raise Protocol2000Error, "REMOTE not supported yet"
        
    def event_define_machine(self, input, output) :         
        """Gets the number of I/O ports for a given machine."""
        if self.parent.lastoutput == DEFINE_VIDEO :
            if input == ACTION_DEFINE_INPUTS :
                self.numberOfVideoInputs = output
            elif input == ACTION_DEFINE_OUTPUTS :
                self.numberOfVideoOutputs = output
            elif input == ACTION_DEFINE_SETUPS :
                self.numberOfVideoSetups = output
            else :
                raise Protocol2000Error, repr((input, output))
        elif self.parent.lastoutput == DEFINE_AUDIO :
            if input == ACTION_DEFINE_INPUTS :
                self.numberOfAudioInputs = output
            elif input == ACTION_DEFINE_OUTPUTS :
                self.numberOfAudioOutputs = output
            elif input == ACTION_DEFINE_SETUPS :
                self.numberOfAudioSetups = output
            else :
                raise Protocol2000Error, repr((input, output))
        elif self.parent.lastoutput == DEFINE_SDI :
            if input == ACTION_DEFINE_INPUTS :
                self.numberOfSDIInputs = output
            elif input == ACTION_DEFINE_OUTPUTS :
                self.numberOfSDIOutputs = output
            elif input == ACTION_DEFINE_SETUPS :
                self.numberOfSDISetups = output
            else :
                raise Protocol2000Error, repr((input, output))
        elif self.parent.lastoutput == DEFINE_REMOTE :
            if input == ACTION_DEFINE_INPUTS :
                self.numberOfRemoteInputs = output
            elif input == ACTION_DEFINE_OUTPUTS :
                self.numberOfRemoteOutputs = output
            elif input == ACTION_DEFINE_SETUPS :
                self.numberOfRemoteSetups = output
            else :
                raise Protocol2000Error, repr((input, output))
        else :
            raise Protocol2000Error, repr((input, output))
        
    #
    # Callable interface starts here
    def reset_video(self) :
        self.dialog("Reset Video", 0, 0)
        
    def disconnect_video(self, output=ALL_OUTPUTS) :
        """Disconnects video."""
        self.dialog("Switch Video", ACTION_DISCONNECT, output)
        
    def disconnect_audio(self, output=ALL_OUTPUTS) :
        """Disconnects video."""
        self.dialog("Switch Audio", ACTION_DISCONNECT, output)
        
    def switch_video(self, input, output=DEFAULT_OUTPUT) :
        """Switches the given video input to the given video output."""
        self.dialog("Switch Video", input, output)
        
    def switch_audio(self, input, output=DEFAULT_OUTPUT) :    
        """Switches the given audio input to the given audio output."""
        self.dialog("Switch Audio", input, output)
        
    def store_video_status(self, setupregister=SETUP_REGISTER_CURRENT) :    
        """Stores the video status into the given setup register."""
        self.dialog("Store Video Status", setupregister, ACTION_STORE_STATUS)
    
    def delete_video_status(self, setupregister=SETUP_REGISTER_CURRENT) :    
        """Deletes the video status from the given setup register."""
        self.dialog("Store Video Status", setupregister, ACTION_DELETE_STATUS)
        
    def recall_video_status(self, setupregister=SETUP_REGISTER_CURRENT) :    
        """Recalls the video status stored in the given setup register."""
        self.dialog("Recall Video Status", setupregister, ACTION_RECALL_STATUS)
        
    def request_video_output_status(self, setupregister=SETUP_REGISTER_CURRENT, output=DEFAULT_OUTPUT) :    
        """Requests the video output status stored in the given setup register."""
        self.dialog("Request Video Output Status", setupregister, output)
        
    def request_audio_output_status(self, setupregister=SETUP_REGISTER_CURRENT, output=DEFAULT_OUTPUT) :    
        """Requests the audio output status stored in the given setup register."""
        self.dialog("Request Audio Output Status", setupregister, output)
        
    def vis_source(self, input, output) :    
        """Not implemented yet"""
        raise Protocol2000Error, "VIS Source not yet implemented"
    
    def set_audio_follow_video(self) :
        """Sets the audio follow video flag."""
        self.dialog("Breakaway Setting", 0, ACTION_AUDIO_FOLLOW_VIDEO)
 
    def set_audio_breakaway(self) :
        """Sets the audio breakaway flag."""
        self.dialog("Breakaway Setting", 0, ACTION_AUDIO_BREAKAWAY)
        
    def video_audio_type_setting(self, input, output) :    
        """Not implemented yet"""
        raise Protocol2000Error, "Video Audio Type Setting not yet implemented"
    
    def request_vis_setting(self, input, output) :    
        """Not implemented yet"""
        raise Protocol2000Error, "Request VIS Setting not yet implemented"
    
    def has_breakaway_setting(self) :    
        """Checks if the given machine accepts a breakaway setting."""
        self.dialog("Request Breakaway Setting", ACTION_HASFUNCTION, 0)
    
    def request_breakaway_setting(self, setupregister=SETUP_REGISTER_CURRENT) :    
        """Requests the breakaway setting"""
        self.dialog("Request Breakaway Setting", setupregister, 0)
    
    def request_audio_type_setting(self, setupregister=SETUP_REGISTER_CURRENT) :
        """Requests the Audio Type Setting."""
        self.dialog("Request Video Audio Type Setting", setupregister, ACTION_AUDIO_TYPE_SETTING)
        
    def request_video_type_setting(self, setupregister=SETUP_REGISTER_CURRENT) :
        """Requests the Video Type Setting."""
        self.dialog("Request Video Audio Type Setting", setupregister, ACTION_VIDEO_TYPE_SETTING)
        
    def has_request_audio_type_setting(self) :
        """Checks if the given machine has Request Audio Type Setting."""
        self.dialog("Request Video Audio Type Setting", ACTION_HASFUNCTION, ACTION_AUDIO)
        
    def has_request_video_type_setting(self) :
        """Checks if the given machine has Request Video Type Setting."""
        self.dialog("Request Video Audio Type Setting", ACTION_HASFUNCTION, ACTION_VIDEO)
        
    def set_highest_video_machine_number(self, highest) :
        """Sets the highest video machine number. TODO check to see if machine parameter is needed."""
        self.dialog("Set Highest Machine Number", ACTION_VIDEO, highest, DEFAULT_MACHINE)
    
    def set_highest_audio_machine_number(self, highest) :
        """Sets the highest audio machine number. TODO check to see if machine parameter is needed."""
        self.dialog("Set Highest Machine Number", ACTION_AUDIO, highest, DEFAULT_MACHINE)
    
    def request_highest_video_machine_number(self) :
        """Requests the highest video machine number. TODO check to see if machine parameter is needed."""
        self.dialog("Request Highest Machine Number", ACTION_VIDEO, 0, DEFAULT_MACHINE)
    
    def request_highest_audio_machine_number(self) :
        """Requests the highest audio machine number. TODO check to see if machine parameter is needed."""
        self.dialog("Request Highest Machine Number", ACTION_AUDIO, 0, DEFAULT_MACHINE)
        
    def request_whether_setup_is_defined(self, setupregister=SETUP_REGISTER_CURRENT) :    
        """Requests whether given setup register is defined."""
        self.dialog("Request Whether Setup Is Defined", setupregister, 0)
        
    def error_busy(self, errorcode) :    
        """Sends an error code to the given machine. This is forbidden."""
        raise Protocol2000Error, "Protocol2000 Violation : Can't send an error code %i to the grid" % errorcode
        
    def reset_audio(self) :    
        """Resets the audio."""
        self.dialog("Reset Audio", 0, 0)
        
    def store_audio_status(self, setupregister=SETUP_REGISTER_CURRENT) :    
        """Stores the audio status into the given setup register."""
        self.dialog("Store Audio Status", setupregister, ACTION_STORE_STATUS)
    
    def delete_audio_status(self, setupregister=SETUP_REGISTER_CURRENT) :    
        """Deletes the audio status from the given setup register."""
        self.dialog("Store Audio Status", setupregister, ACTION_DELETE_STATUS)
        
    def set_video_gain(self, gain=0, outputchannel=ALL_OUTPUTS) :
        """Sets the output video gain."""
        self.dialog("Set Video Gain", outputchannel, gain)
        
    def set_audio_gain(self, gain=0, outputchannel=ALL_OUTPUTS) :
        """Sets the output audio gain."""
        self.dialog("Set Audio Gain", outputchannel, gain)
        
    def increase_decrease_video_gain(self, variation=0, outputchannel=ALL_OUTPUTS) :
        """Increases or Decreases the output video gain."""
        self.dialog("Increase Decrease Video Gain", outputchannel, variation)
        
    def increase_decrease_audio_gain(self, variation=0, outputchannel=ALL_OUTPUTS) :
        """Increases or Decreases the output audio gain."""
        self.dialog("Increase Decrease Audio Gain", outputchannel, variation)
        
    def request_video_gain(self, outputchannel=ALL_OUTPUTS) :
        """Requests the output video gain."""
        self.dialog("Request Gain", outputchannel, ACTION_VIDEO)
    
    def request_audio_gain(self, outputchannel=ALL_OUTPUTS) :
        """Requests the output audio gain."""
        self.dialog("Request Gain", outputchannel, ACTION_AUDIO)
    
    def has_request_video_gain(self) :
        """Checks if the machine has Request Video Gain."""
        self.dialog("Request Gain", ACTION_HASFUNCTION, ACTION_VIDEO)
    
    def has_request_audio_gain(self) :
        """Checks if the machine has Request Audio Gain."""
        self.dialog("Request Gain", ACTION_HASFUNCTION, ACTION_AUDIO)
    
    def set_auto_save(self) :
        """Sets the auto save flag."""
        self.dialog("Set Auto Save", ACTION_AUTOSAVE, 0)
        
    def unset_auto_save(self) :
        """Unsets the auto save flag."""
        self.dialog("Set Auto Save", ACTION_NO_AUTOSAVE, 0)
        
    def identify_video_machine_name(self) :    
        """Asks a video machine for its name."""
        self.dialog("Identify Machine", ACTION_VIDEO_MACHINE_NAME, 0)
        
    def identify_audio_machine_name(self) :    
        """Asks a audio machine for its name."""
        self.dialog("Identify Machine", ACTION_AUDIO_MACHINE_NAME, 0)
        
    def identify_video_software_version(self) :    
        """Asks a video machine for its software version."""
        self.dialog("Identify Machine", ACTION_VIDEO_SOFTWARE_VERSION, 0)
        
    def identify_audio_software_version(self) :    
        """Asks a audio machine for its software version."""
        self.dialog("Identify Machine", ACTION_AUDIO_SOFTWARE_VERSION, 0)
        
    def identify_remote_control_name(self) :    
        """Asks a remote control for its name."""
        self.dialog("Identify Machine", ACTION_REMOTE_CONTROL_NAME, 0)
        
    def identify_remote_control_software_version(self) :    
        """Asks a remote control for its software version."""
        self.dialog("Identify Machine", ACTION_REMOTE_CONTROL_SOFTWARE_VERSION, 0)
        
    def define_machine_number_of_video_inputs(self) :       
        """Asks a machine for its number of video inputs."""
        self.dialog("Define Machine", ACTION_DEFINE_INPUTS, DEFINE_VIDEO)
        
    def define_machine_number_of_audio_inputs(self) :       
        """Asks a machine for its number of audio inputs."""
        self.dialog("Define Machine", ACTION_DEFINE_INPUTS, DEFINE_AUDIO)
        
    def define_machine_number_of_sdi_inputs(self) :       
        """Asks a machine for its number of sdi inputs."""
        self.dialog("Define Machine", ACTION_DEFINE_INPUTS, DEFINE_SDI)
        
    def define_machine_number_of_remote_inputs(self) :       
        """Asks a machine for its number of remote inputs."""
        self.dialog("Define Machine", ACTION_DEFINE_INPUTS, DEFINE_REMOTE)
        
    def define_machine_number_of_video_outputs(self) :       
        """Asks a machine for its number of video outputs."""
        self.dialog("Define Machine", ACTION_DEFINE_OUTPUTS, DEFINE_VIDEO)
        
    def define_machine_number_of_audio_outputs(self) :       
        """Asks a machine for its number of audio outputs."""
        self.dialog("Define Machine", ACTION_DEFINE_OUTPUTS, DEFINE_AUDIO)
        
    def define_machine_number_of_sdi_outputs(self) :       
        """Asks a machine for its number of sdi outputs."""
        self.dialog("Define Machine", ACTION_DEFINE_OUTPUTS, DEFINE_SDI)
        
    def define_machine_number_of_remote_outputs(self) :       
        """Asks a machine for its number of remote outputs."""
        self.dialog("Define Machine", ACTION_DEFINE_OUTPUTS, DEFINE_REMOTE)
        
    def define_machine_number_of_video_setups(self) :       
        """Asks a machine for its number of video setups."""
        self.dialog("Define Machine", ACTION_DEFINE_SETUPS, DEFINE_VIDEO)
        
    def define_machine_number_of_audio_setups(self) :       
        """Asks a machine for its number of audio setups."""
        self.dialog("Define Machine", ACTION_DEFINE_SETUPS, DEFINE_AUDIO)
        
    def define_machine_number_of_sdi_setups(self) :       
        """Asks a machine for its number of sdi setups."""
        self.dialog("Define Machine", ACTION_DEFINE_SETUPS, DEFINE_SDI)
        
    def define_machine_number_of_remote_setups(self) :       
        """Asks a machine for its number of remote setups."""
        self.dialog("Define Machine", ACTION_DEFINE_SETUPS, DEFINE_REMOTE)
                            
if __name__ == "__main__" :        
    # Initialize connection quickly
    if len(sys.argv) >= 2 :
        dev = sys.argv[1]
    else :
        dev = "/dev/ttyS0"
    prot = Protocol2000(device=dev, debug=1) 
    kramer = prot.Machines[1]
    
    #kramer = Protocol2000_Machine() 
    
    # gets the current selected video and audio inputs on machine 1 / output 1 
    # our VS601-XLM has only one video output and one audio output
    # but both are split in three identical streams so in any case 
    # the output number is always 1, and since we've got only one switcher,
    # the machine number is always 1 too.
    
    print "DГ©connexion totale : ",
    kramer.disconnect_video()
    print "OK"
    time.sleep(1)
    kramer.reset_video()
    time.sleep(1)
    kramer.reset_audio()
    time.sleep(1)
    
    kramer.define_machine_number_of_video_outputs()
    print "Nombre de sorties Video : %i" % kramer.numberOfVideoOutputs
    kramer.define_machine_number_of_video_inputs()
    print "Nombre d'entrГ©es Video : %i" % kramer.numberOfVideoInputs
    
    for j in range(1, kramer.numberOfVideoOutputs + 1) :
        for i in range(1, kramer.numberOfVideoInputs + 1) :
            sys.stdout.write("SГ©lection entrГ©e %i sur sortie %i: " % (i, j))
            kramer.switch_video(i, j)
            sys.stdout.write("OK\n")
            time.sleep(1)
        sys.stdout.write("\n")    
        
    kramer.define_machine_number_of_audio_outputs()
    print "Nombre de sorties Audio : %i" % kramer.numberOfAudioOutputs
    kramer.define_machine_number_of_audio_inputs()
    print "Nombre d'entrГ©es Audio : %i" % kramer.numberOfAudioInputs
    
    # get current BreakAway setting
    kramer.has_breakaway_setting()
    if kramer.hasBreakawaySetting :
        canbreak = 1
        kramer.request_breakaway_setting()
        status = kramer.currentBreakawaySetting
        if status == ACTION_AUDIO_FOLLOW_VIDEO :
            message = "audio follow video"
        elif status == ACTION_AUDIO_BREAKAWAY :    
            message = "audio breakaway"
        else :    
            raise Protocol2000Error, "Unknown breakaway status %i" % status
    else :    
        canbreak = 0
        message = "unbreakable"
    print "Current breakaway setting : %s" % message
    if canbreak :
        # we can break audio from video, just try this !
        kramer.set_audio_breakaway()
        kramer.request_breakaway_setting()
        status = kramer.currentBreakawaySetting
        if status == ACTION_AUDIO_FOLLOW_VIDEO :
            message = "audio follow video"
        elif status == ACTION_AUDIO_BREAKAWAY :    
            message = "audio breakaway"
        else :    
            raise Protocol2000Error, "Unknown breakaway status %i" % status
        print "New breakaway setting : %s" % message    
        
    print "DГ©connexion totale : ",
    kramer.disconnect_video()
    print "OK"
    time.sleep(1)
    
    kramer.request_video_output_status()
    print "Current video input : %i" % kramer.VideoOutputs[1]
    
    kramer.request_audio_output_status()
    print "Current audio input : %i" % kramer.AudioOutputs[1]
    

    kramer.set_auto_save()
    time.sleep(1)
    kramer.unset_auto_save()
    time.sleep(1)
    
    kramer.has_request_video_gain()
    time.sleep(1)
    kramer.has_request_audio_gain()
    time.sleep(1)
    
    print " Inputs : %s" % kramer.VideoInputs
    print "Outputs : %s" % kramer.VideoOutputs
