#ifndef AHB_MASTER_C
#define AHB_MASTER_C
    #include "ahb_master.h"

AHB_MASTER::AHB_MASTER(uint8_t id){

} 
  
    
#endif /* AHB_MASTER_C */