/**#include "ahb_eth.h"
AHB_ETH::AHB_ETH (uint8_t _cspin ) { //,uint16_t server_port){ //= 10  = 0
_interface.init(_cspin);
  //if (server_port>0){
  //  EthernetServer server(server_port);
  //  server.begin(server_port);
  //}
}
*/