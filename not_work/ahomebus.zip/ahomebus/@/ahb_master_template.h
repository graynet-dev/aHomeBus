#ifndef AHB_MASTER_T_H
#define AHB_MASTER_T_H
#include "ahb_master_template.h"
#include "ahb_proto.h"

class AHB_MCOMM {
        public:
            virtual uint8_t master_test(void);
};
#endif //AHB_MASTER_T_H