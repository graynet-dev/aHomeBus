#ifndef AHB_MASTER_C
#define AHB_MASTER_C

#include "ahb_master.h"
#include "ahb.h"

#endif //AHB_MAASTER_C