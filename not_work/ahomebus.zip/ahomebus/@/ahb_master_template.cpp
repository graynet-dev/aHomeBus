#ifndef AHB_MASTER_T_C
#define AHB_MASTER_T_C
    #include "ahb_master_template.h"
#endif /* AHB_MASTER_T_C */