#ifndef AHB_MASTER_H
#define AHB_MASTER_H

#include "ahb.h"
#include "ahb_master.h"

class AHB_MM {
        private: 
      
        public:
            //bool NodeGuard_OK[255][3] = {{ 0 }}; //[2]

            // Up Time remote node 
            //uint8_t ut_rn[256][6]; 
           
            /**
            * 
            */
            //Constructor
            AHB_MM(void);
            //Init
            virtual byte begin(void);
            
            virtual void test(void);
            //byte yyy(byte val);
            //void yyy_uptime(void);        
};        
        
#endif //AHB_MASTER_H
