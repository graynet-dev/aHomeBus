#ifndef AHB_MASTER2_H
#define AHB_MASTER2_H

#include "ahb.h"

class AHB_MMO : public AHB_MM {
        private:

            //MCP_CAN _interface;

            byte _intPin = 0;

            byte _speed = 0;

            byte _clockspd = 0;
                       
        public:

            AHB_MMO(void);
            
            byte begin(void);
            
            void test(void);            

};


/*class AHB_MASTER2:public AHB_MASTER{
        private: 
      
        public:
            bool NodeGuard_OK[255][3] = {{ 0 }}; //[2]

            // Up Time remote node 
            uint8_t ut_rn[256][6]; 
         
            //Constructor
            AHB_MASTER2(void);
            //Init
            byte begin(void);
            
            void test(void);
            //byte yyy(byte val);
            //void yyy_uptime(void);        
};    */    
        
#endif //AHB_MASTER_H

