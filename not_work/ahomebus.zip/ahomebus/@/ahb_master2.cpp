#ifndef AHB_MASTER2_C
#define AHB_MASTER2_C

#include "ahb_master2.h"
#include "ahb.h"

AHB_MMO::AHB_MMO(void)  { 
Serial.println(" CONSTRUCTOR MASTER CLASS "); 
}

byte AHB_MMO::begin() {
Serial.println(" BEGIN MASTER CLASS "); 
}

void AHB_MMO::test() {
Serial.println(" test "); 
}
#endif //AHB_MAASTER_C