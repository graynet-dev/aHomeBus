#ifndef AHB_SLAVE_C
#define AHB_MSLAVE_C
    #include "ahb_slave.h"

AHB_SLAVE::AHB_SLAVE(uint8_t id){

} 
  
    
#endif /* AHB_SLAVE_C */